import { Injectable } from '@angular/core';

@Injectable()
export class GlobalVar {
  // Local Host
  public rootURL = 'http://localhost:44307/api';

}


