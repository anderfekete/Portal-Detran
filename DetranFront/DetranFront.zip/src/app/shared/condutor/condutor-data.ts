export class CondutorData {
    id = 0;
    nome = '';
    cpf = '';
    telefone = '';
    email = '';
    cnh = '';
    nascimento: string | null = '';
}
