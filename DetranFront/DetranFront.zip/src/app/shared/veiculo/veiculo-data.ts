export class VeiculoData {
    id = 0;
    modelo = '';
    marca = '';
    placa = '';
    cor = '';
    anoFabricacao = '';
}
