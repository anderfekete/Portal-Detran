export class UsuarioData {
    usu_n_codigo: number = 0;
    usu_c_nome: string = "";
    usu_c_email: string = "";
    usu_c_senha: string = "";
}
