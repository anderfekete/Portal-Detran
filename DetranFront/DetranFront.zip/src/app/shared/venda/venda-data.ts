export class VendaData {
  Id = 0;
  IdVeiculo = 0;
  IdCondutor = 0;
}
