export class LoginData {
    usu_c_email: string = "";
    usu_c_senha: string = "";
}
