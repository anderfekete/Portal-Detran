export interface CompraVendaData {
    modelo: string;
    marca: string;
    placa: string;
    cor: string;
    anoFabricacao: string;
}
